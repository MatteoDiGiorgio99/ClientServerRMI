package it.unipr.digiorgio;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Set;

/**
 * The {@code ClientsOfferListImpl} class implements the ClientsOfferList
 * interface, managing client offer subscriptions.
 * 
 * @author Matteo Di Giorgio 353719
 */
public class ClientsOfferListImpl extends UnicastRemoteObject implements ClientsOfferList {

	private static final long serialVersionUID = 1L;
	private Set<ProductOffer> offers;

	/**
	 * Constructor of ProductsOffersListImpl object.
	 * 
	 * @param offers List of client offers
	 * @throws RemoteException If a remote communication error occurs
	 */
	public ClientsOfferListImpl(Set<ProductOffer> offers) throws RemoteException {
		this.offers = offers;
	}

	@Override
	public void subscribe(ProductOffer o) throws RemoteException {
		this.offers.add(o);
	}

	@Override
	public void unsubcribe(ProductOffer o) throws RemoteException {
		this.offers.remove(o);
	}

}
