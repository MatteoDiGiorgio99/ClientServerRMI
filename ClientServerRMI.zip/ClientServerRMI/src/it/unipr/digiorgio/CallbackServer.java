package it.unipr.digiorgio;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;

/**
 * /**
 * The {@code CallbackServer} class represents a server that starts selling
 * products when at least 3 clients have subscribed.
 * It runs until all clients have completed their purchases, periodically
 * updates product prices, and checks client offers.
 * If an offer is higher than the product price, it confirms the offer,
 * otherwise it rejects it.
 * 
 * @author Matteo Di Giorgio 353719
 */
public class CallbackServer {
	private static final int port = 1099;
	private static final int min = 10;
	private static final int max = 200;
	private static final int min_clients = 3;

	/**
	 * Constructor of CallbackClient class
	 */
	public CallbackServer() {
	}

	/**
	 * The main method of the CallbackServer class.
	 * 
	 * @param args the command-line arguments
	 * @throws Exception if an error occurs during the execution of the method
	 */
	public static void main(String[] args) throws Exception {

		Registry registry = LocateRegistry.createRegistry(port);

		// Create list of products
		Set<Product> products = productsList(3 * 10);
		ProductsList productsList = new ProductsListImpl(products);
		registry.rebind("productsList", productsList);

		// Create list of clients offers
		Set<ProductOffer> offers = new CopyOnWriteArraySet<>();
		ClientsOfferList offersList = new ClientsOfferListImpl(offers);
		registry.rebind("offersList", offersList);

		// Wait clients
		while (offers.size() < min_clients) {
			System.out.println("Wait clients: " + offers.size() + "/" + min_clients);
			Thread.sleep(2000);
		}

		// There are clients that want buy
		while (offers.size() > 0) {
			for (Product product : products) {
				((ProductImpl) product).setPrice(max, min);
				System.out.println("--------------------");
				System.out.println("Product SN: " + product.getSN());
				System.out.println("Product Price: $" + product.getPrice());
			}
			try {
				Thread.sleep(2000);
				// For each client check offer
				for (ProductOffer offer : offers) {
					int sn = offer.getSN();
					int o = offer.getOffer();
					if (o > 0 && sn > 0) {
						Product p = productsList.getProduct(sn);

						System.out.println("--------------------");
						System.out.println("Product SN: " + sn);
						System.out.println("Product Price: $" + p.getPrice());
						System.out.println("Client Offer: $" + o);
						if (p.getPrice() <= o) {
							offer.setConfirm(true);
							System.out.println("Offer accepted");
						} else {
							offer.setConfirm(false);
							System.out.println("Offer rejected");
						}

					}
					Thread.sleep(300);
				}
			} catch (Exception e) {
				continue;
			}
		}

		System.out.println("All clients are disconnected. Shop close.");
		UnicastRemoteObject.unexportObject(productsList, false);
		UnicastRemoteObject.unexportObject(offersList, false);
	}

	/**
	 * Create a list of products with prices between (max, min) and SN
	 * between (1, num_product)
	 * 
	 * @param num_products Number of products
	 * @return List of products
	 * @throws Exception if an error occurs during the execution of the method
	 */
	private static Set<Product> productsList(int num_products) throws Exception {
		Set<Product> products = new CopyOnWriteArraySet<>();
		for (int i = 0; i < num_products; i++) {
			ProductImpl product = new ProductImpl();
			product.setSN(i + 1);
			product.setPrice(max, min);
			products.add(product);
		}
		return products;
	}

}
