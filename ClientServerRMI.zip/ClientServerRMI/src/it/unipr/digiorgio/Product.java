package it.unipr.digiorgio;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * The {@code Product} interface represents a product, providing methods to get
 * its price and serial number.
 * 
 * @author Matteo Di Giorgio 353719
 */
public interface Product extends Remote {
	/**
	 * Returns the price of the product.
	 * 
	 * @return The current price of the product
	 * @throws RemoteException If a remote communication error occurs
	 */
	int getPrice() throws RemoteException;

	/**
	 * Returns the serial number of the product.
	 * 
	 * @return The serial number of the product
	 * @throws RemoteException If a remote communication error occurs
	 */
	int getSN() throws RemoteException;
}