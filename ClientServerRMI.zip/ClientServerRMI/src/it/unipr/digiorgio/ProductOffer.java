package it.unipr.digiorgio;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * /**
 * The {@code ProductOffer} interface represents a product offer, providing
 * methods for offer retrieval and confirmation.
 * 
 * @author Matteo Di Giorgio 353719
 */
public interface ProductOffer extends Remote {

	/**
	 * Returns the offer for the product.
	 * 
	 * @return The client's offer
	 * @throws RemoteException If a remote communication error occurs
	 */
	int getOffer() throws RemoteException;

	/**
	 * Returns the serial number of the product.
	 * 
	 * @return The serial number of the product
	 * @throws RemoteException If a remote communication error occurs
	 */
	int getSN() throws RemoteException;

	/**
	 * Confirms the client's offer.
	 * 
	 * @param confirmed The server's offer response
	 * @throws RemoteException If a remote communication error occurs
	 */
	void setConfirm(Boolean confirmed) throws RemoteException;
}