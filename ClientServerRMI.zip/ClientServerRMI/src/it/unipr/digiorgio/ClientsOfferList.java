package it.unipr.digiorgio;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 *
 * The {@code OffersList} interface manages client offer subscriptions in a
 * distributed system.
 * 
 * @author Matteo Di Giorgio 353719
 */
public interface ClientsOfferList extends Remote {
	/**
	 * Subscribe to list of products buyers
	 * 
	 * @param offer The remote object of the client
	 * @throws RemoteException If a remote communication error occurs
	 */
	void subscribe(final ProductOffer offer) throws RemoteException;

	/**
	 * Unsubscribe from list of products buyers
	 * 
	 * @param offer The remote object of the client
	 * @throws RemoteException If a remote communication error occurs
	 */
	void unsubcribe(final ProductOffer offer) throws RemoteException;
}