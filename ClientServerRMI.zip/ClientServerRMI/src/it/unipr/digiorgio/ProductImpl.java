package it.unipr.digiorgio;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Random;

/**
 * The {@code ProductImpl} class implements the Product interface, managing a
 * product's price and serial number.
 * 
 * @author Matteo Di Giorgio 353719
 */
public class ProductImpl extends UnicastRemoteObject implements Product {

	private static final long serialVersionUID = 1L;
	private int price;
	private int sn;

	/**
	 * Constructor of ProductImpl object.
	 * Initializes the price and serial number to 0.
	 *
	 * @throws RemoteException If there is a problem with the remote object
	 *                         communication.
	 */
	public ProductImpl() throws RemoteException {
		this.price = 0;
		this.sn = 0;
	}

	@Override
	public int getPrice() throws RemoteException {
		return this.price;
	}

	@Override
	public int getSN() throws RemoteException {
		return this.sn;
	}

	/**
	 * Local method to set the serial number of the product.
	 *
	 * @param sn The serial number of the product.
	 */
	public void setSN(int sn) {
		this.sn = sn;
	}

	/**
	 * Local method to set the price of the product.
	 *
	 * @param max The maximum price for the product.
	 * @param min The minimum price for the product.
	 */
	public void setPrice(int max, int min) {
		this.price = new Random().nextInt(max - min) + min;
	}

}
