package it.unipr.digiorgio;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.Set;

/**
 * The {@code ProductsListImpl} class implements the ProductsList interface,
 * managing product retrieval.
 *
 * 
 * @author Matteo Di Giorgio 353719
 */
public class ProductsListImpl extends UnicastRemoteObject implements ProductsList {

	private static final long serialVersionUID = 1L;
	private Set<Product> products;

	/**
	 * Constructor of ProductsListImpl object.
	 * Initializes the products with the specified set of products.
	 * 
	 * @param p The set of products
	 * @throws RemoteException If a remote communication error occurs
	 */
	public ProductsListImpl(final Set<Product> p) throws RemoteException {
		this.products = p;
	}

	@Override
	public Product getProduct(int sn) throws RemoteException {
		for (Product p : this.products) {
			if (p.getSN() == sn) {
				return p;
			}
		}
		return new ProductImpl();
	}

	@Override
	public ArrayList<Integer> getSNs() throws RemoteException {
		ArrayList<Integer> sns = new ArrayList<>();

		for (Product p : this.products) {
			sns.add(p.getSN());
		}
		return sns;
	}
}