package it.unipr.digiorgio;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.Random;

/**
 * /**
 * The {@code CallbackClient} class represents a client using RMI to interact
 * with a remote server.
 * It subscribes to an offer list, makes purchases from a product list, and
 * creates a remote object for offer retrieval.
 * The client periodically selects a product, makes a random offer, and awaits a
 * server response.
 * The client stops after 10 purchases.
 * 
 * @author Matteo Di Giorgio 353719
 */

public class CallbackClient {
	private static final int Min = 10;
	private static final int Max = 200;
	private static final int purchases = 10;

	/**
	 * Constructor of CallbackClient class
	 */
	public CallbackClient() {
	}

	/**
	 * Runnable method to run client
	 *
	 * @param args the command-line arguments
	 * @throws Exception if an error occurs during the execution of the method
	 */
	public static void main(String[] args) throws Exception {
		Registry registry = LocateRegistry.getRegistry();

		ProductOffer myOffer = new ProductOfferImpl();

		ProductsList productsList = (ProductsList) registry.lookup("productsList");

		ClientsOfferList offersList = (ClientsOfferList) registry.lookup("offersList");
		offersList.subscribe(myOffer);

		int productsCount = 0;

		// Client didn't end to purchases
		while (productsCount < purchases) {
			ArrayList<Integer> sns = productsList.getSNs();

			// If list of SN is empty client waits
			if (!sns.isEmpty()) {
				int sn = getRandomSN(sns);
				int offer = getRandomOffer();
				int price = productsList.getProduct(sn).getPrice();
				((ProductOfferImpl) myOffer).setSN(sn);
				((ProductOfferImpl) myOffer).setOffer(offer);

				System.out.println("-------------------------");
				System.out.println("Product SN: " + sn);
				System.out.println("Product Price: " + price);
				System.out.println("Offer: " + offer);

				Boolean confirm = null;
				while (confirm == null) {
					Thread.sleep(1000);
					confirm = ((ProductOfferImpl) myOffer).getConfirm();
				}
				if (confirm) {
					productsCount++;
					System.out.println("-------------------------");
					System.out.println("Congratulations! Your offer has been accepted!");
					System.out.println("You have successfully purchased the product with SN: " + sn);
					System.out.println("Price: $" + offer);
				} else {
					System.out.println("-------------------------");
					System.out.println("Oops! Your offer has been rejected!");
					System.out.println("The product with SN: " + sn + " is no longer available at the offered price.");
					System.out.println("Please try again with a different offer.");
				}

				myOffer.setConfirm(null);
				((ProductOfferImpl) myOffer).setOffer(0);
				((ProductOfferImpl) myOffer).setSN(0);
			}
			System.out.println(productsCount + "/" + purchases);
			Thread.sleep(2000);
		}
		System.out.println("Leaving the shop.");
		offersList.unsubcribe(myOffer);
		UnicastRemoteObject.unexportObject(myOffer, false);
	}

	/**
	 * Return a random product SN
	 *
	 * @param array ArrayList of products SN
	 * @return Random product SN
	 */
	public static int getRandomSN(ArrayList<Integer> array) {
		int rnd = new Random().nextInt(array.size());
		return array.get(rnd);
	}

	/**
	 * Return a random offer for a product
	 *
	 * @return Random offer between MIN_PRICE and MAX_PRICE
	 */
	public static int getRandomOffer() {
		return new Random().nextInt(Max - Min) + Min;
	}
}
