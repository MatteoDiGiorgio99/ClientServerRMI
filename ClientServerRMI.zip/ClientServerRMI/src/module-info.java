/**
 * The RMI module provides support for Remote Method Invocation (RMI) in Java.
 * RMI allows objects in a Java Virtual Machine (JVM) to invoke methods on
 * objects in another JVM, even if those objects are located on a different machine.
 * This module requires the java.rmi module and exports the it.unipr.digiorgio packages to the java.rmi module.
 * <p>
 * 
 * 
 * The goal is to realize a client - server application for cost-effective product purchasing.
 * The application is to be developed with RMI.
 * <p> 
 * This application involves a server and a number of clients (at least 3).
 * The products are priced within a range of €10 to €200.
 * The server periodically randomly generates sale prices and informs clients of their value.
 * Each client receives product prices from time to time, randomly generates the maximum purchase price
 * (always in the range between €10 and €200) and sends a purchase request to the server if the sale price is less than the maximum purchase price.
 * <p>
 * The server, upon receiving the buy request, sends a sell confirmation if the buy price is greater than or
 * equal to the current sale price; otherwise it sends a rejection message.
 * Each client ends its activity after the same number of purchases (at least 10).
 * When all clients have completed their purchases, the server terminates the application.
 * 
 * @author Matteo Di Giorgio 353719
 */
module ClientServerRMI {
	requires java.rmi;
	exports it.unipr.digiorgio to java.rmi;

}